# Attribution

MolCrafts Design is distributed under MIT. Vega and Vega-Lite are developed by the University of Washington Interactive Data Lab and contributors and distributed under BSD-3-Clause. Their installed dependency license texts are retained in THIRD_PARTY_NOTICES.md. No MolPlot implementation is copied.
